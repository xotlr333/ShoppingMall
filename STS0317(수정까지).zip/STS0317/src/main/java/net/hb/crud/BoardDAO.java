package net.hb.crud;

import java.util.List;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {
	
	@Autowired
	SqlSessionTemplate temp;
	
	public void dbInsert(BoardDTO dto) {
		temp.insert("board.add", dto);
		System.out.println("dbInsert�޼ҵ�(dto)hobby���̺� ���强��");
	}//end
	
	public List<BoardDTO> dbList( ){
		//List<BoardDTO> list = temp.selectList("board.selectAll");
		return temp.selectList("board.selectAll");
	}//end
	
	public int dbCount( ){
		return temp.selectOne("board.countAll");
	}//end
	
	public BoardDTO dbDetail(int data) {
		BoardDTO dto = temp.selectOne("board.detail",data);
		return dto;
	}//end
	
	public void dbDelete(int data) {
		temp.delete("board.delete",data);
	}//end
	
	public void dbEdit(BoardDTO dto) {
		temp.update("board.edit",dto);
	}//end
	
}//class END


