package net.hb.crud;

import java.io.File;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class BoardController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);

	@Autowired
	ServletContext  application;
	
	@Autowired
	BoardDAO dao;
	
	
	@RequestMapping(value = "/boardWrite.do", method = RequestMethod.GET)
	public String board_write() {
		return "boardWrite";  //boardWrite.jsp
	}//end
	
	@RequestMapping("/boardInsert.do")
	public String  board_insert(BoardDTO dto) {		
		String path=application.getRealPath("/resources/upload"); 
		String img=dto.getUpload_f().getOriginalFilename(); 
		File file = new File(path, img);
		
		try{dto.getUpload_f().transferTo(file);}catch(Exception e) {	}
		dto.setImg_file_name(img);
		
		dao.dbInsert(dto);
		//return "boardList"; //boardList.jsp
		return "redirect:/boardList.do"; //���弭���� response.sendRedirect("boardList.do");
	}//end
	
	@RequestMapping("/boardList.do")
	public String  board_select(Model model) {
		int Gtotal = dao.dbCount();
		List<BoardDTO> LG = dao.dbList();
		model.addAttribute("LG",LG);
		model.addAttribute("Gtotal",Gtotal);
		//LG��ü���� ��boardList.jsp������ ��� �ѱ�� requset����� 
		return "boardList"; //boardList.jsp
	}//end
	
	@RequestMapping("/boardDetail.do")
	public String board_detail( HttpServletRequest request ,Model model) {
		BoardDTO dto = dao.dbDetail(Integer.parseInt(request.getParameter("idx")));
		model.addAttribute("dto",dto);
		return "boardDetail";
	}
	
	@RequestMapping("/boardDelete.do")
	public String board_delete( HttpServletRequest request) {
		dao.dbDelete(Integer.parseInt(request.getParameter("idx")));
		return "redirect:/boardList.do";
	}
	
	@RequestMapping("/boardPreEdit.do")
	public String board_preEdit( HttpServletRequest request ,Model model) {
		BoardDTO dto = dao.dbDetail(Integer.parseInt(request.getParameter("idx")));
		model.addAttribute("dto",dto);
		return "boardEdit";
	}
	
	@RequestMapping("/boardEdit.do")
	public String board_edit(BoardDTO dto ) {
		
		String path=application.getRealPath("/resources/upload"); 
		String img=dto.getUpload_f().getOriginalFilename(); 
		File file = new File(path, img);
		
		try{dto.getUpload_f().transferTo(file);}catch(Exception e) {	}
		dto.setImg_file_name(img);
		
		dao.dbEdit(dto);
		return "redirect:/boardList.do";
	}
	
}//class END








