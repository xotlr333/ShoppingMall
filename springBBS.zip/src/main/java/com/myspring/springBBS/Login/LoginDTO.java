package com.myspring.springBBS.Login;

public class LoginDTO {
	private String s_id;
	private String s_name;
	private String s_gender;
	private String s_phone;
	private String s_email;
	
	public String getS_id() {
		return s_id;
	}
	
	public void setS_id(String s_id) {
		this.s_id = s_id;
	}
	
	public String getS_name() {
		return s_name;
	}
	
	public void setS_name(String s_name) {
		this.s_name = s_name;
	}
	
	public String getS_gender() {
		return s_gender;
	}
	
	public void setS_gender(String s_gender) {
		this.s_gender = s_gender;
	}
	
	public String getS_phone() {
		return s_phone;
	}
	
	public void setS_phone(String s_phone) {
		this.s_phone = s_phone;
	}
	
	public String getS_email() {
		return s_email;
	}
	
	public void setS_email(String s_email) {
		this.s_email = s_email;
	}
	
}//class EDN
